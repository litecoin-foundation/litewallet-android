0.19.0 note
-----------

Due to a last-minute issue (#17449), 0.19.0, although it was tagged, was never released.

See the release notes for 0.19.0.1 instead.
